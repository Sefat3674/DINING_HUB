package com.example.hall_dining

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
